<?php require 'header.php'; ?>
<br><br><br><br><br>
<div class="container">
      <h1>Ubah Profile</h1>
      <br>
      <form method="post">
      	<table class="table">
	        <tbody>
	          <tr>
	            <td></td>
	            <td>
	                 <img class="rounded" src="assets/images/01.jpg" width="300">
	                 <br><br>
	                 <div class="input-group mb-3">
					  <div class="input-group-prepend">
					  </div>
					  <div class="custom-file">
					    <input type="file" class="custom-file-input" id="inputGroupFile03">
					    <label class="custom-file-label" for="inputGroupFile03">Choose file</label>
					  </div>
					</div>
	            </td>
	          </tr>
	          <tr>
	            <td>Nama</td>
	            <td>
	            	<div class="form-group">
					  <input type="text" class="form-control" name="nama" value="Ihsan Karunia Mindara">
					</div>
	            </td>
	          </tr>
	          <tr>
	            <td>Email</td>
	            <td>
	            	<div class="form-group">
					  <input type="email" class="form-control" name="email" value="ihsankarunia09@gmail.com">
					</div>
	            </td>
	          </tr>
	          <tr>
	            <td>Deskripsi</td>
	            <td>
	            	<textarea class="form-control"></textarea>
	            </td>
	          </tr>
	        </tbody>
	      </table>
      </form>
      <a href="index.php" class="btn btn-outline-danger btn-sm">Kembali</a>
      <button type="button" class="btn btn-outline-primary btn-sm">Ubah Profile</button>
    </div>
<br><br><br><br><br>
<?php require 'footer.php'; ?>
