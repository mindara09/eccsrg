<!DOCTYPE html>
<html >
<head>
  <!-- Site made with Mobirise Website Builder v4.6.5, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.6.5, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/artboard-3-972x972.png" type="image/x-icon">
  <meta name="description" content="">
  <title>Computer Security &amp; Researcher Group</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons-bold/mobirise-icons-bold.css">
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  
</head>
<body>
  <section class="menu cid-rRqhcmeZOs" once="menu" id="menu2-m">

    

    <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm bg-color transparent">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="https://mobirise.com">
                        <img src="assets/images/artboard-3-972x972.png" alt="Mobirise" title="" style="height: 3.8rem;">
                    </a>
                </span>
                
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item dropdown open">
                    <a class="nav-link link text-black dropdown-toggle display-4" href="https://mobirise.com" data-toggle="dropdown-submenu" aria-expanded="true">Penetration Testing</a><div class="dropdown-menu"><div class="dropdown"><a class="text-black dropdown-item dropdown-toggle display-4" href="https://mobirise.com" data-toggle="dropdown-submenu" aria-expanded="false">Wireless Hacking</a><div class="dropdown-menu dropdown-submenu"><a class="text-black dropdown-item display-4" href="https://mobirise.com">Hacking Wifi</a><a class="text-black dropdown-item display-4" href="https://mobirise.com">Man in The Middle Attack</a></div></div><div class="dropdown open"><a class="text-black dropdown-item dropdown-toggle display-4" href="https://mobirise.com" data-toggle="dropdown-submenu" aria-expanded="true">Web Hacking</a><div class="dropdown-menu dropdown-submenu"><a class="text-black dropdown-item display-4" href="https://mobirise.com">SQL Injection</a><a class="text-black dropdown-item display-4" href="https://mobirise.com">XSS (Reflected)</a><a class="text-black dropdown-item display-4" href="https://mobirise.com">XSS (DOM)</a><a class="text-black dropdown-item display-4" href="https://mobirise.com">XSS (Stored)</a><a class="text-black dropdown-item display-4" href="https://mobirise.com">File Upload Vulnerability</a><a class="text-black dropdown-item display-4" href="https://mobirise.com">Local File Inclusion</a><a class="text-black dropdown-item display-4" href="https://mobirise.com">OS Command Injection</a><a class="text-black dropdown-item display-4" href="https://mobirise.com">Bruteforce</a><a class="text-black dropdown-item display-4" href="https://mobirise.com">CSRF</a></div></div><div class="dropdown"><a class="text-black dropdown-item dropdown-toggle display-4" href="https://mobirise.com" aria-expanded="false" data-toggle="dropdown-submenu">Hacking Server</a><div class="dropdown-menu dropdown-submenu"><a class="text-black dropdown-item display-4" href="https://mobirise.com" aria-expanded="false">Bruteforce SSH Server</a><a class="text-black dropdown-item display-4" href="https://mobirise.com" aria-expanded="false">Bruteforce MySQL Server</a><a class="text-black dropdown-item display-4" href="https://mobirise.com" aria-expanded="false">Bruteforce Telnet Server</a><a class="text-black dropdown-item display-4" href="https://mobirise.com" aria-expanded="false">Bruteforce FTP Server</a><a class="text-black dropdown-item display-4" href="https://mobirise.com" aria-expanded="false">Hacking Samba Server</a></div></div><div class="dropdown"><a class="text-black dropdown-item dropdown-toggle display-4" href="https://mobirise.com" data-toggle="dropdown-submenu" aria-expanded="false">Hacking Tutorial Series<br></a><div class="dropdown-menu dropdown-submenu"><a class="text-black dropdown-item display-4" href="https://mobirise.com">Metasploit<br></a><a class="text-black dropdown-item display-4" href="https://mobirise.com">Phising<br></a><a class="text-black dropdown-item display-4" href="https://mobirise.com">Hacking Windows 7, 8, 10<br></a><a class="text-black dropdown-item display-4" href="https://mobirise.com">Hacking Android<br></a></div></div><a class="text-black dropdown-item display-4" href="https://mobirise.com" aria-expanded="true">Tools Hacking in Windows Series<br></a></div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link link text-black dropdown-toggle display-4" href="https://mobirise.com" data-toggle="dropdown-submenu" aria-expanded="false">Web Developer</a><div class="dropdown-menu"><div class="dropdown"><a class="text-black dropdown-item dropdown-toggle display-4" href="https://mobirise.com" data-toggle="dropdown-submenu" aria-expanded="false">Front End Developer</a><div class="dropdown-menu dropdown-submenu"><a class="text-black dropdown-item display-4" href="https://mobirise.com">Figma</a><a class="text-black dropdown-item display-4" href="https://mobirise.com">Adobe XD</a><a class="text-black dropdown-item display-4" href="https://mobirise.com">Bootstrap</a><a class="text-black dropdown-item display-4" href="https://mobirise.com">Materialize</a></div></div><div class="dropdown"><a class="text-black dropdown-item dropdown-toggle display-4" href="https://mobirise.com" data-toggle="dropdown-submenu" aria-expanded="false">Back End Developer</a><div class="dropdown-menu dropdown-submenu"><a class="text-black dropdown-item display-4" href="https://mobirise.com">PHP Native</a><a class="text-black dropdown-item display-4" href="https://mobirise.com">CodeIgniter</a><a class="text-black dropdown-item display-4" href="https://mobirise.com">Laravel</a></div></div></div>
                </li><li class="nav-item dropdown"><a class="nav-link link text-black dropdown-toggle display-4" href="https://mobirise.com" data-toggle="dropdown-submenu" aria-expanded="false">Networking</a><div class="dropdown-menu"><a class="text-black dropdown-item display-4" href="https://mobirise.com">Mikrotik</a><a class="text-black dropdown-item display-4" href="https://mobirise.com">Cisco</a></div></li><li class="nav-item"><a class="nav-link link text-black display-4" href="https://mobirise.com" aria-expanded="true">System Administration</a></li></ul>
            <div class="navbar-buttons mbr-section-btn"><a class="btn btn-sm btn-primary display-4" href="profile.php"><span class="mbri-smile-face mbr-iconfont mbr-iconfont-btn"></span>Profile&nbsp;</a></div>
        </div>
    </nav>
</section>