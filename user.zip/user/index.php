<?php require 'header.php'; ?>

<section class="engine"></section><section class="cid-rQWWj0b1gj mbr-fullscreen mbr-parallax-background" id="header2-3">

    

    <div class="mbr-overlay" style="opacity: 0.5; background-color: rgb(35, 35, 35);"></div>

    <div class="container align-center">
        <div class="row justify-content-md-center">
            <div class="mbr-white col-md-10">
                <h1 class="mbr-section-title mbr-bold pb-3 mbr-fonts-style display-1">E-Course | CSRG</h1>
                
                <p class="mbr-text pb-3 mbr-fonts-style display-5">
                    Dengan adanya E-Course ini, dapat menjadi pembelajaran bagi mahasiswa STMIK "AMIKBANDUNG" maupun umum yang giat dalam belajar dunia IT, salah satunya <strong>Cyber Security</strong>, <strong>Web Developer, System Administration&nbsp;</strong>dan <strong>Networking</strong></p>
                <div class="mbr-section-btn"><a class="btn btn-md btn-secondary display-4" href="https://mobirise.com">Our Modul</a>
                    <a class="btn btn-md btn-white-outline display-4" href="https://mobirise.com">Silabus</a></div>
            </div>
        </div>
    </div>
    <div class="mbr-arrow hidden-sm-down" aria-hidden="true">
        <a href="#next">
            <i class="mbri-down mbr-iconfont"></i>
        </a>
    </div>
</section>

<section class="header12 cid-rQWWmDqlDW mbr-fullscreen mbr-parallax-background" id="header12-4">

    

    <div class="mbr-overlay" style="opacity: 0.7; background-color: rgb(35, 35, 35);">
    </div>

    <div class="container  ">
            <div class="media-container">
                <div class="col-md-12 align-center">
                    <h1 class="mbr-section-title pb-3 mbr-white mbr-bold mbr-fonts-style display-1">Our Modul</h1>
                    <p class="mbr-text pb-3 mbr-white mbr-fonts-style display-5">Disini kita menyediakan pembelajaran secara online dengan materi berikut :</p>
                    <div class="mbr-section-btn align-center py-2"><a class="btn btn-md btn-secondary display-4" href="https://mobirise.com">Kuy Belajar!</a></div>

                    <div class="icons-media-container mbr-white">
                        <div class="card col-12 col-md-6 col-lg-3">
                            <div class="icon-block">
                            <a href="pentest/">
                                <span class="mbr-iconfont mbrib-lock"></span>
                            </a>
                            </div>
                            <h5 class="mbr-fonts-style display-5">
                                Penetration Testing</h5>
                        </div>

                        <div class="card col-12 col-md-6 col-lg-3">
                            <div class="icon-block">
                                <a href="https://mobirise.com/">
                                    <span class="mbr-iconfont mbrib-arrow-prev"></span>
                                </a>
                            </div>
                            <h5 class="mbr-fonts-style display-5">
                                Web Developer</h5>
                        </div>

                        <div class="card col-12 col-md-6 col-lg-3">
                            <div class="icon-block">
                                <a href="https://mobirise.com/">
                                    <span class="mbr-iconfont mbrib-globe-2"></span>
                                </a>
                            </div>
                            <h5 class="mbr-fonts-style display-5">Networking</h5>
                        </div>

                        <div class="card col-12 col-md-6 col-lg-3">
                            <div class="icon-block">
                                <a href="https://mobirise.com/">
                                    <span class="mbr-iconfont mbrib-setting2"></span>
                                </a>
                            </div>
                            <h5 class="mbr-fonts-style display-5">
                                System Administration</h5>
                        </div>
                    </div>
                </div>
            </div>
    </div>

    <div class="mbr-arrow hidden-sm-down" aria-hidden="true">
        <a href="#next">
            <i class="mbri-down mbr-iconfont"></i>
        </a>
    </div>
</section>

<?php require 'footer.php'; ?>