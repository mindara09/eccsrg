<?php require 'header.php'; ?>

<br><br><br><br>
<div class="container">
	<div class="container">
		<h1>Detail Materi</h1>
		<br>
		<form method="post">
			<label id="judull"><b>Judul :</b></label>
			<p>Introduction</p>
			<br>
			<label><b>Sub Materi :</b></label>
			<p>Introduction</p>
			<br>
			<label id="urll"><b>Url :</b></label>
			<p>ASdasadsaXZNIASd</p>
			<br>
			<label><b>Deskripsi :</b></label>
			<p style="text-align: justify;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			<br>
			<label><b>Foto Thumbnail :</b></label><br>
			<img src="assets/images/01.jpg" class="rounded img-responsive" width="300">

			<br><br>
			<a href="index.php" class="btn btn-outline-danger btn-sm">Kembali</a>
			<button type="button" data-toggle="modal" data-target="#materiUbah" class="btn btn-primary btn-sm">Ubah Materi</button>
		</form>
	</div>
</div>
<br><br><br><br>

<!-- Modal -->
<div class="modal fade" id="materiUbah" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">UBAH MATERI</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post">
			<label id="judull">Judul :</label>
			<input type="text" name="judul" class="form-control">
			<br>
			<label>Sub Materi</label>
			<div class="input-group mb-3">
			  <select class="custom-select" id="inputGroupSelect01">
			    <option selected>Pilih...</option>
			    <option value="">Introduction</option>
			    <option value="">Wireless Hacking</option>
			    <option value="">Web Hacking</option>
			    <option value="">Hacking Server</option>
			    <option value="">Hacking Tutorial Series</option>
			    <option value="">Hacking Tools in Windows Series</option>
			  </select>
			</div>
			<br>
			<label id="urll">Url :</label>
			<input type="text" name="judul" class="form-control">
			<br>
			<label>Deskripsi :</label>
			<textarea class="form-control" name="deskripsi"></textarea>
			<br>
			<label>Foto Thumbnail :</label>
			<div class="input-group mb-3">
			  <div class="input-group-prepend">
			    <span class="input-group-text">Upload</span>
			  </div>
			  <div class="custom-file">
			    <input type="file" class="custom-file-input" id="inputGroupFile01">
			    <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
			  </div>
			</div>

			<br>
			<div class="modal-footer">
		       <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
		       <button type="button" class="btn btn-primary btn-sm" name="ubahMateri">Simpan</button>
		    </div>
		</form>
      </div>
      
    </div>
  </div>
</div>


<?php include'footer.php'; ?>