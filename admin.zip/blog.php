<?php include 'header.php'; ?>

<br><br><br><br>

<div class="container">
	<div class="container">
		<center>
			<h1 class="btn-outline-danger btn">GO-BLOG KUY!</h1>
		
			<table class="table">
				<thead>
					<tr>
						<th>Date</th>
						<th>Title</th>
						<th>Action</th>
					</tr>
				</thead>
			</table>

		</center>
		<br>
	</div>
</div>

<br><br><br><br>


<?php include 'footer.php'; ?>