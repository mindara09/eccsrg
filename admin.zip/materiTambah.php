<?php require 'header.php'; ?>

<br><br><br><br>
<div class="container">
	<div class="container">
		<h1>Input Materi</h1>
		<br>
		<form method="post">
			<label id="judull">Judul :</label>
			<input type="text" name="judul" class="form-control">
			<br>
			<label>Sub Materi</label>
			<div class="input-group mb-3">
			  <select class="custom-select" id="inputGroupSelect01">
			    <option selected>Pilih...</option>
			    <option value="">Introduction</option>
			    <option value="">Wireless Hacking</option>
			    <option value="">Web Hacking</option>
			    <option value="">Hacking Server</option>
			    <option value="">Hacking Tutorial Series</option>
			    <option value="">Hacking Tools in Windows Series</option>
			  </select>
			</div>
			<br>
			<label id="urll">Url :</label>
			<input type="text" name="judul" class="form-control">
			<br>
			<label>Deskripsi :</label>
			<textarea class="form-control" name="deskripsi"></textarea>
			<br>
			<label>Foto Thumbnail :</label>
			<div class="input-group mb-3">
			  <div class="input-group-prepend">
			    <span class="input-group-text">Upload</span>
			  </div>
			  <div class="custom-file">
			    <input type="file" class="custom-file-input" id="inputGroupFile01">
			    <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
			  </div>
			</div>

			<br>
			<a href="index.php" class="btn btn-outline-danger btn-sm">Kembali</a>
			<button name="simpan" class="btn btn-primary btn-sm">Simpan</button>
		</form>
	</div>
</div>
<br><br><br><br>


<?php include'footer.php'; ?>