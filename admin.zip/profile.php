<?php require 'header.php'; ?>

<br><br><br><br><br>
 <div class="container">
      <h1>Profile</h1>
      <br>
      <table class="table">
        <tbody>
          <tr>
            <td></td>
            <td>
                 <img class="rounded" src="assets/images/01.jpg" width="300">
            </td>
          </tr>
          <tr>
            <td>Nama</td>
            <td>Ihsan Karunia Mindara</td>
          </tr>
          <tr>
            <td>Email</td>
            <td>ihsankarunia09@gmail.com</td>
          </tr>
          <tr>
            <td>Divisi</td>
            <td>Penetration Testing</td>
          </tr>
          <tr>
            <td>Deskripsi</td>
            <td style="text-align: justify;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
            consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
            cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
            proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</td>
          </tr>
        </tbody>
      </table>
      <a href="index.php" class="btn btn-outline-danger btn-sm">Kembali</a>
      <a href="profileUbah.php" class="btn btn-outline-primary btn-sm">Ubah Profile</a>
    </div>
<br><br><br><br>

<?php require 'footer.php'; ?>